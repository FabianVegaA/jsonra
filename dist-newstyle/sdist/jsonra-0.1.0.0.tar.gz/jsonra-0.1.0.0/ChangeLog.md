# Changelog for jsonra

## Unreleased changes
